import java.util.Scanner;

class main {
    public static void main (String[] args) {
        int Q=0, u, W=0, E=0, pass, prod, choice, qnt, cad, forpag;
        double car=0, carne, arroz, farinha, sal, newvalue;
        carne=59.99;
        arroz=7.69;
        farinha=3.99;
        sal=1.49;
        Scanner sc = new Scanner (System.in);

        while (Q!=2) {
            System.out.println("Bem vindo ao Mercado ADANS! Escolha sua forma de entrada:\n1-Cliente\n2-Funcionario");
            u = sc.nextInt ();
            switch (u) {
                case 1 ://SISTEMA RODANDO COMO CLIENTE
                    System.out.println("Ola! Navegue com comodidade e escolha quais itens adicionar ao seu carrinho!");
                    while (E!=1) {
                        System.out.println("Escolha um produto para adicionar ao carrinho:\n1-Carne R$"+carne+"\n2-Arroz    R$"+arroz+"\n3-Farinha  R$"+farinha+"\n4-Sal    R$"+sal);
                        prod = sc.nextInt ();
                        System.out.println("Quantas unidades voce quer deste produto?");
                        qnt = sc.nextInt ();
                        switch (prod) {
                            case 1 :
                                System.out.println("CARNE ADICIONADO AO CARRINHO");
                                car=car+carne*qnt;
                                System.out.println("Seu carrinho: R$"+car);
                            break;
                            case 2 :
                                System.out.println("ARROZ ADICIONADO AO CARRINHO");
                                car=car+arroz*qnt;
                                System.out.println("Seu carrinho: R$"+car);
                            break;
                            case 3 :
                                System.out.println("FARINHA ADICIONADO AO CARRINHO");
                                car=car+farinha*qnt;
                                System.out.println("Seu carrinho: R$"+car);
                            break;
                            case 4 :
                                System.out.println("SAL ADICIONADO AO CARRINHO");
                                car=car+sal*qnt;
                                System.out.println("Seu carrinho: R$"+car);
                            break;
                            default :
                                System.out.println("Ops! Ainda nao trabalhamos com esse produto.");
                            break;
                        }//ESCOLHA DE PRODUTOS PELO CLIENTE
                        System.out.println("Deseja finalizar sua compra?\n1-Sim\n2-Nao");
                        E = sc.nextInt ();
                    }
                    System.out.println("O valor total da sua compra e R$"+car);
                    System.out.println("Gostaria de realizar cadastro?\n1-Sim\n2-Nao");
                    cad = sc.nextInt ();
                    if (cad==1) {//REALIZAÇÃO DE CADASTRO DE CLIENTE
                        System.out.println("Digite seu CPF:");
                        sc.nextInt();
                        car=car-(car*0.12);
                        System.out.println("Veja so! Ja esta funcionando! O novo valor total de sua compra COM DESCONTO e de R$"+car);
                        System.out.println("Qual a forma de pagamento?\n1-Dinheiro\n2-Pix\n3-Debito\n4-Credito");
                        forpag = sc.nextInt ();
                        switch (forpag) {//ADD FORMA DE PAGAMENTO DA COMPRA
                            case 1 :
                                System.out.println("Certo, seu pagamento sera a vista!");
                            break;
                            case 2 :
                                System.out.println("Certo, seu pagamento sera via Pix!");
                            break;
                            case 3 :
                                System.out.println("Certo, seu pagamento sera mediante cartao de debito!");
                            break;
                            case 4 :
                                System.out.println("Certo, seu pagamento sera mediante cartao de credito!");
                            break;
                            default :
                                System.out.println("Escolha uma opcao valida.");
                            break;
                        }
                    }else {
                        System.out.println("Sua compra esta finalizada no total de R$"+car);
                        System.out.println("Qual a forma de pagamento?\n1-Dinheiro\n2-Pix\n3-Debito\n4-Credito");
                        forpag = sc.nextInt ();
                        switch (forpag) {
                            case 1 :
                                System.out.println("Certo, seu pagamento sera a vista!");
                                break;
                            case 2 :
                                System.out.println("Certo, seu pagamento sera via Pix!");
                                break;
                            case 3 :
                                System.out.println("Certo, seu pagamento sera mediante cartao de debito!");
                                break;
                            case 4 :
                                System.out.println("Certo, seu pagamento sera mediante cartao de credito!");
                                break;
                            default :
                                System.out.println("Escolha uma opcao valida.");
                                break;
                        }
                    }
                break;
                case 2 ://SISTEMA RODANDO COMO ADMIN
                    System.out.println("Digite a senha de administrador:");
                    pass = sc.nextInt ();
                    if (pass==1234) {
                        while (W!=2){
                            System.out.println("Produtos disponives:\n1-Carne R$"+carne+"\n2-Arroz    R$"+arroz+"\n3-Farinha  R$"+farinha+"\n4-Sal    R$"+sal);
                            prod = sc.nextInt ();
                            switch (prod) {
                                case 1 :
                                    System.out.println("Voce escolheu Carne.\nDeseja alterar o valor do produto?\n1-Sim\n2-Nao");
                                    choice = sc.nextInt ();
                                    if (choice==1) {
                                        System.out.println("Digite o novo valor do produto");
                                        newvalue = sc.nextDouble ();
                                        System.out.println("O valor foi alterado.\nNovo valor: R$"+newvalue);
                                    }
                                break;
                                case 2 :
                                    System.out.println("Voce escolheu Arroz.\nDeseja alterar o valor do produto?\n1-Sim\n2-Nao");
                                    choice = sc.nextInt ();
                                    if (choice==1) {
                                        System.out.println("Digite o novo valor do produto:");
                                        newvalue = sc.nextDouble ();
                                        System.out.println("O valor foi alterado.\nNovo valor: R$"+newvalue);
                                    }
                                break;
                                case 3 :
                                    System.out.println("Voce escolheu Farinha.\nDeseja alterar o valor do produto?\n1-Sim\n2-Nao");
                                    choice = sc.nextInt ();
                                    if (choice==1) {
                                        System.out.println("Digite o novo valor do produto:");
                                        newvalue = sc.nextDouble ();
                                        System.out.println("O valor foi alterado.\nNovo valor: R$"+newvalue);
                                    }
                                break;
                                case 4 :
                                    System.out.println("Voce escolheu Sal.\nDeseja alterar o valor do produto?\n1-Sim\n2-Nao");
                                    choice = sc.nextInt ();
                                    if (choice==1) {
                                        System.out.println("Digite o novo valor do produto:");
                                        newvalue = sc.nextDouble ();
                                        System.out.println("O valor foi alterado.\nNovo valor: R$"+newvalue);
                                    }
                                break;
                                default :
                                    System.out.println("Escolha uma opcao valida");
                                break;
                            } // ESCOLHA DE PRODUTO PELO ADM PARA ALTERAÇÃO DE PREÇOS
                            System.out.println("Deseja continuar alterando os precos?\n1-Sim\n2-Nao");
                            W = sc.nextInt ();
                        }//LOOP DE RETORNO DO OPERADOR
                    }else {
                        System.out.println("Senha incorreta!\nTente novamente.");
                    }
                break;
                default :
                    System.out.println("Digite uma opcao valida");
                break;
            }
            System.out.println("Deseja continuar no sistema?\n1-Sim\n2-Nao");
            Q = sc.nextInt ();
        }
        System.out.println("Obrigado por escolher o Mercado ADANS");
    }
}